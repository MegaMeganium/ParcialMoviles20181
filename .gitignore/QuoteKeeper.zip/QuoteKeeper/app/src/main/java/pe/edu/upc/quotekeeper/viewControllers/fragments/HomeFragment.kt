package pe.edu.upc.quotekeeper.viewControllers.fragments


import android.content.Intent
import android.os.Bundle
import android.support.v4.app.Fragment
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import com.androidnetworking.error.ANError
import kotlinx.android.synthetic.main.fragment_home.view.*

import pe.edu.upc.quotekeeper.R
import pe.edu.upc.quotekeeper.models.BookMark
import pe.edu.upc.quotekeeper.models.QuoteRandom
import pe.edu.upc.quotekeeper.network.TalaikisApi


/**
 * A simple [Fragment] subclass.
 *
 */
class HomeFragment : Fragment() {
    lateinit var quoteTextView: TextView
    lateinit var authorTextView: TextView
    lateinit var catTextView: TextView
    lateinit var buttonMore: Button
    lateinit var icon: ImageButton

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_home, container, false)
        quoteTextView = view.quoteTextView
        authorTextView = view.authorTextView
        catTextView = view.catTextView
        buttonMore = view.moreButton
        icon = view.iconQuoteSaved

        TalaikisApi.getRandQuote(
                { response -> responseHandler(response) },
                { error -> errorHandler(error) })

        buttonMore.setOnClickListener { _ ->
            TalaikisApi.getRandQuote(
                    { response -> responseHandler(response) },
                    { error -> errorHandler(error) })
        }

        icon.setOnClickListener { _ ->
            val isBookmark = BookMark.existsOnDB(quoteTextView.text.toString())
            if(isBookmark){
                BookMark.deleteOne(quoteTextView.text.toString())
            } else {
                BookMark.saveOne(QuoteRandom(quoteTextView.text.toString()
                        ,authorTextView.text.toString(),
                        catTextView.text.toString()))
            }
            icon.setImageResource(imageResourceFor(!isBookmark))
        }

        return view
    }

    private fun responseHandler(response: QuoteRandom?) {
        quoteTextView.text = response!!.quote
        authorTextView.text = response.author
        catTextView.text = response.cat
        icon.setImageResource(imageResourceFor(BookMark.existsOnDB(quoteTextView.text.toString())))
    }

    private fun errorHandler(anError: ANError?){
        Log.d("QuoteKeeper", anError!!.message)
    }

    fun imageResourceFor(isBookmarked: Boolean) : Int{
        return if(isBookmarked){
            R.drawable.ic_bookmark_black_24dp
        } else {
            R.drawable.ic_bookmark_border_black_24dp
        }
    }
}
