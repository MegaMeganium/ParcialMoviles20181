package pe.edu.upc.quotekeeper.models

import android.os.Bundle
import com.orm.SugarRecord

data class QuoteRandom(
        val quote: String? = "",
        val author: String? = "",
        val cat: String? = "") {

    companion object {
        fun from(bundle: Bundle): QuoteRandom{
            return QuoteRandom(
                    bundle.getString("quote"),
                    bundle.getString("author"),
                    bundle.getString("cat")
            )
        }
    }

    fun toBundle(): Bundle{
        val bundle = Bundle()
        bundle.putString("quote", quote)
        bundle.putString("author", author)
        bundle.putString("cat", cat)
        return bundle
    }

    fun isBookmarked() : Boolean{
        return SugarRecord.find(BookMark::class.java,
                "quote = ?",
                quote).size > 0
    }

}