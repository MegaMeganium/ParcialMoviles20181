package pe.edu.upc.quotekeeper.network

import com.androidnetworking.AndroidNetworking
import com.androidnetworking.common.Priority
import com.androidnetworking.error.ANError
import com.androidnetworking.interfaces.ParsedRequestListener
import pe.edu.upc.quotekeeper.models.QuoteRandom

class TalaikisApi {
    companion object {
        val randomQuote = "https://talaikis.com/api/quotes/random/"

        fun getRandQuote(responseHandler: (QuoteRandom?) ->Unit, errorHandler: (ANError?) -> Unit){
            AndroidNetworking.get(TalaikisApi.randomQuote).setPriority(Priority.LOW).build()
                    .getAsObject(QuoteRandom::class.java, object : ParsedRequestListener<QuoteRandom?>{
                        override fun onResponse(response: QuoteRandom?) {
                            responseHandler(response)
                        }

                        override fun onError(anError: ANError?) {
                            errorHandler(anError)
                        }
                    })
        }
    }
}