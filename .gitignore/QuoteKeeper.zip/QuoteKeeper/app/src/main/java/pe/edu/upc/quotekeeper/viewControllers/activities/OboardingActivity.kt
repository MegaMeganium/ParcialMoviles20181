package pe.edu.upc.quotekeeper.viewControllers.activities

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_oboarding.*
import pe.edu.upc.quotekeeper.R

class OboardingActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_oboarding)

        initTextView.text = getString(R.string.welcome)

        startButton.setOnClickListener { view ->
            val context = view.context
            startActivity(Intent(context, MainActivity::class.java))
        }
    }
}
