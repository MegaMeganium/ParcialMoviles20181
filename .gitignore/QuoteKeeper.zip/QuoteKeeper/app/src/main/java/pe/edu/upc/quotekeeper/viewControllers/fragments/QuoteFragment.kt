package pe.edu.upc.quotekeeper.viewControllers.fragments


import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.widget.GridLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import kotlinx.android.synthetic.main.fragment_quote.view.*

import pe.edu.upc.quotekeeper.R
import pe.edu.upc.quotekeeper.models.BookMark
import pe.edu.upc.quotekeeper.models.QuoteRandom
import pe.edu.upc.quotekeeper.viewControllers.adapters.QuoteAdapter

/**
 * A simple [Fragment] subclass.
 *
 */
class QuoteFragment : Fragment() {

    var quotes = ArrayList<BookMark>()
    lateinit var quoteRecyclerView: RecyclerView
    lateinit var quoteAdapter: QuoteAdapter
    lateinit var quoteLayoutManager: RecyclerView.LayoutManager

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_quote, container, false)

        quotes = BookMark.listAllQuotes() as ArrayList<BookMark>
        quoteRecyclerView = view.quoteRecyclerView
        quoteAdapter = QuoteAdapter(quotes, view.context)
        quoteLayoutManager = GridLayoutManager(view.context, 1)

        quoteRecyclerView.adapter = quoteAdapter
        quoteRecyclerView.layoutManager = quoteLayoutManager

        return view
    }


}
